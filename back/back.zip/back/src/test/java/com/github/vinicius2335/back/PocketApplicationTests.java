package com.github.vinicius2335.back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
